import React, { useState, useMemo } from 'react';
import { 
  Search, Flame, Filter, ExternalLink, AlertTriangle, 
  Sparkles, Plus, Check, SlidersHorizontal, Eye 
} from 'lucide-react';
import { MenuItem, CATEGORIES, RESTAURANT_META } from '../data/restaurantData';

interface MenuSectionProps {
  items: MenuItem[];
  onSelectItem: (item: MenuItem) => void;
  onAddToCart: (item: MenuItem) => void;
  cartItemIds: string[];
  onOpenPriceEditor: () => void;
}

export const MenuSection: React.FC<MenuSectionProps> = ({
  items,
  onSelectItem,
  onAddToCart,
  cartItemIds,
  onOpenPriceEditor,
}) => {
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const filteredItems = useMemo(() => {
    return items.filter((item) => {
      const matchesCategory =
        activeCategory === 'all' || item.category === activeCategory;
      const matchesSearch =
        item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.ingredients.some((ing) => ing.toLowerCase().includes(searchQuery.toLowerCase()));
      return matchesCategory && matchesSearch;
    });
  }, [items, activeCategory, searchQuery]);

  return (
    <section id="menu" className="py-20 bg-[#0b0d10] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-10 pb-6 border-b border-stone-800">
          <div className="space-y-3">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-400 text-xs font-semibold">
              <Flame className="w-3.5 h-3.5" />
              <span>قائمة طعام أمواج الكاملة</span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-white">
              استكشف <span className="text-amber-400">منيو المشويات والوجبات</span>
            </h2>
            <p className="text-stone-400 text-sm max-w-2xl">
              تصفح أصناف مشويات الفحم، شاورما الصاج، وجبات البروستد المقرمشة، البرجر، والبحريات مع الأسعار الاسترشادية للمعاينة.
            </p>
          </div>

          <div className="flex items-center gap-3">
            {/* Quick Price Editor Drawer Trigger */}
            <button
              onClick={onOpenPriceEditor}
              className="inline-flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl bg-stone-800/80 hover:bg-stone-700 text-stone-200 border border-stone-700 text-xs font-semibold transition-colors cursor-pointer"
              title="تعديل الأسعار والبيانات للمعاينة"
            >
              <SlidersHorizontal className="w-3.5 h-3.5 text-amber-400" />
              <span>محرر الأسعار للمعاينة</span>
            </button>

            {/* Talabat Menu Button */}
            <a
              href={RESTAURANT_META.links.talabatMenu}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-[#ea580c] hover:bg-[#c2410c] text-white text-xs font-bold transition-all shadow-md shadow-orange-950/40"
            >
              <span>منيو طلبات الرسمي</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>
        </div>

        {/* Pricing Disclaimer Alert Box */}
        <div className="mb-8 p-4 rounded-2xl bg-amber-950/30 border border-amber-500/30 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-amber-200 text-xs">
          <div className="flex items-center gap-3">
            <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0" />
            <div>
              <span className="font-bold text-amber-300 block sm:inline ml-1">
                تنويه الأسعار الاسترشادية:
              </span>
              جميع الأسعار المعروضة في هذا النموذج مبنية على قائمة طلبات المعلنة للمعاينة فقط، وتحتاج إلى اعتماد المطعم الرسمي قبل إطلاق النسخة النهائية.
            </div>
          </div>
          <button
            onClick={onOpenPriceEditor}
            className="text-amber-400 hover:text-white underline font-semibold shrink-0 cursor-pointer text-xs"
          >
            تعديل الأسعار سريعاً
          </button>
        </div>

        {/* Search & Categories Bar */}
        <div className="space-y-4 mb-10">
          
          {/* Search Box */}
          <div className="relative max-w-xl">
            <Search className="w-5 h-5 text-stone-400 absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="ابحث عن صنف، مكونات، أو تتبيلة (مثال: بروستد، شيش طاووق، جمبري، شاورما...)"
              className="w-full bg-[#121620] border border-stone-800 rounded-xl pr-12 pl-4 py-3 text-stone-100 placeholder-stone-500 text-sm focus:outline-none focus:border-amber-500 transition-colors"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute left-3 top-1/2 -translate-y-1/2 text-xs text-stone-400 hover:text-stone-200"
              >
                مسح
              </button>
            )}
          </div>

          {/* Category Tabs */}
          <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
            {CATEGORIES.map((cat) => {
              const isActive = activeCategory === cat.id;
              return (
                <button
                  key={cat.id}
                  onClick={() => setActiveCategory(cat.id)}
                  className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold whitespace-nowrap transition-all cursor-pointer ${
                    isActive
                      ? 'bg-amber-500 text-stone-950 shadow-md shadow-amber-500/20'
                      : 'bg-[#121620] text-stone-300 hover:text-white hover:bg-stone-800 border border-stone-800/80'
                  }`}
                >
                  {cat.nameAr}
                </button>
              );
            })}
          </div>

        </div>

        {/* Items Grid */}
        {filteredItems.length === 0 ? (
          <div className="text-center py-16 bg-[#121620]/50 rounded-2xl border border-stone-800/80">
            <p className="text-stone-400 text-base mb-2">لا توجد نتائج تطابق بحثك حالياً</p>
            <p className="text-stone-500 text-xs">جرب البحث بكلمات أخرى أو اختر قسماً آخر من المنيو</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredItems.map((item) => {
              const inCart = cartItemIds.includes(item.id);

              return (
                <div
                  key={item.id}
                  className="bg-[#121620] hover:bg-[#151a26] border border-stone-800 rounded-2xl overflow-hidden transition-all duration-300 flex flex-col group shadow-lg shadow-black/40"
                >
                  {/* Item Image */}
                  <div
                    className="relative h-48 overflow-hidden cursor-pointer"
                    onClick={() => onSelectItem(item)}
                  >
                    <img
                      src={item.image}
                      alt={item.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      loading="lazy"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-[#121620] via-transparent to-transparent" />
                    
                    {item.badge && (
                      <span className="absolute top-3 right-3 bg-amber-500 text-stone-950 text-xs font-bold px-2.5 py-1 rounded-md shadow-md">
                        {item.badge}
                      </span>
                    )}

                    <div className="absolute bottom-2 left-3 flex items-center gap-1.5 text-[11px] text-stone-300 bg-black/60 backdrop-blur-sm px-2 py-0.5 rounded">
                      <Eye className="w-3 h-3 text-amber-400" />
                      <span>عرض التفاصيل</span>
                    </div>
                  </div>

                  {/* Item Details */}
                  <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
                    <div className="space-y-2">
                      <div className="flex items-start justify-between gap-2">
                        <h3
                          onClick={() => onSelectItem(item)}
                          className="text-base font-bold text-white group-hover:text-amber-400 transition-colors cursor-pointer"
                        >
                          {item.name}
                        </h3>

                        <div className="text-left shrink-0">
                          <span className="text-amber-400 font-extrabold text-base block">
                            {item.price} <span className="text-xs font-normal">ج.م*</span>
                          </span>
                          {item.originalPrice && (
                            <span className="text-stone-500 line-through text-[11px] block">
                              {item.originalPrice} ج.م
                            </span>
                          )}
                        </div>
                      </div>

                      <p className="text-stone-400 text-xs leading-relaxed line-clamp-2">
                        {item.description}
                      </p>

                      <div className="flex items-center gap-2 pt-1 text-[11px] text-stone-500">
                        <span>{item.serving}</span>
                        {item.prepTime && (
                          <>
                            <span>•</span>
                            <span>{item.prepTime}</span>
                          </>
                        )}
                      </div>
                    </div>

                    {/* Card Actions */}
                    <div className="pt-3 border-t border-stone-800/80 flex items-center justify-between gap-2">
                      <button
                        onClick={() => onSelectItem(item)}
                        className="text-xs text-stone-400 hover:text-white underline cursor-pointer"
                      >
                        تفاصيل المكونات
                      </button>

                      <button
                        onClick={() => onAddToCart(item)}
                        className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                          inCart
                            ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                            : 'bg-amber-500/10 hover:bg-amber-500 text-amber-300 hover:text-black border border-amber-500/30'
                        }`}
                      >
                        {inCart ? (
                          <>
                            <Check className="w-3.5 h-3.5" />
                            <span>مضاف للحاسبة</span>
                          </>
                        ) : (
                          <>
                            <Plus className="w-3.5 h-3.5" />
                            <span>أضف للطلب التقديري</span>
                          </>
                        )}
                      </button>
                    </div>

                  </div>
                </div>
              );
            })}
          </div>
        )}

      </div>
    </section>
  );
};
