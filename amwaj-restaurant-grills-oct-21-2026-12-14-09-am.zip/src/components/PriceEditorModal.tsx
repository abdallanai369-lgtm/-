import React, { useState } from 'react';
import { X, SlidersHorizontal, Check, RotateCcw, Save, ShieldAlert } from 'lucide-react';
import { MenuItem } from '../data/restaurantData';

interface PriceEditorModalProps {
  isOpen: boolean;
  onClose: () => void;
  items: MenuItem[];
  onUpdateItemPrice: (id: string, newPrice: number) => void;
  onResetItems: () => void;
  hotline: string;
  onUpdateHotline: (newNumber: string) => void;
}

export const PriceEditorModal: React.FC<PriceEditorModalProps> = ({
  isOpen,
  onClose,
  items,
  onUpdateItemPrice,
  onResetItems,
  hotline,
  onUpdateHotline,
}) => {
  const [localHotline, setLocalHotline] = useState(hotline);
  const [savedNotice, setSavedNotice] = useState(false);

  if (!isOpen) return null;

  const handleSaveHotline = () => {
    onUpdateHotline(localHotline);
    setSavedNotice(true);
    setTimeout(() => setSavedNotice(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div 
        className="relative w-full max-w-2xl bg-[#121620] border border-amber-500/40 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6 text-stone-200 max-h-[90vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-stone-800 pb-4 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center">
              <SlidersHorizontal className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white">محرر أسعار وبيانات المنيو (وضع المعاينة)</h3>
              <p className="text-xs text-stone-400">
                يمكن لإدارة المطعم والمراجعين تعديل الأسعار وأرقام الاتصال هنا لمعاينة التغييرات فوراً.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-stone-800 hover:bg-stone-700 text-stone-300 flex items-center justify-center transition-colors cursor-pointer"
            aria-label="إغلاق"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Central Hotline Editor */}
        <div className="bg-[#171d2a] p-4 rounded-xl border border-stone-800 shrink-0 space-y-2">
          <label className="text-xs font-semibold text-stone-300 block">
            تعديل رقم الخط الساخن المركزي:
          </label>
          <div className="flex items-center gap-2">
            <input
              type="text"
              value={localHotline}
              onChange={(e) => setLocalHotline(e.target.value)}
              className="bg-[#0e1117] border border-stone-700 rounded-lg px-3 py-2 text-sm text-amber-400 font-mono font-bold focus:outline-none focus:border-amber-500 flex-1"
              placeholder="مثال: 15036"
            />
            <button
              onClick={handleSaveHotline}
              className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-black text-xs font-bold rounded-lg transition-colors cursor-pointer shrink-0"
            >
              حفظ الرقم
            </button>
          </div>
          {savedNotice && (
            <span className="text-[11px] text-emerald-400 font-medium block">
              ✓ تم تحديث رقم الخط الساخن في كامل الموقع!
            </span>
          )}
        </div>

        {/* Items Price List Scrollable */}
        <div className="flex-1 overflow-y-auto space-y-2.5 pr-1">
          <div className="text-xs font-bold text-amber-400 mb-2">
            قائمة أسعار الأصناف (تحديث حي):
          </div>

          {items.map((item) => (
            <div
              key={item.id}
              className="bg-[#0e1117] border border-stone-800 rounded-xl p-3 flex items-center justify-between gap-3 text-xs"
            >
              <div className="flex items-center gap-2.5 min-w-0">
                <img
                  src={item.image}
                  alt={item.name}
                  className="w-10 h-10 rounded-lg object-cover shrink-0"
                />
                <div className="truncate">
                  <span className="font-bold text-white block truncate">{item.name}</span>
                  <span className="text-[10px] text-stone-500">{item.serving}</span>
                </div>
              </div>

              {/* Price input */}
              <div className="flex items-center gap-1.5 shrink-0">
                <span className="text-stone-400 font-medium">السعر (ج.م):</span>
                <input
                  type="number"
                  min="0"
                  value={item.price}
                  onChange={(e) => onUpdateItemPrice(item.id, Number(e.target.value) || 0)}
                  className="w-20 bg-[#171d2a] border border-stone-700 rounded-lg px-2 py-1 text-center font-bold text-amber-400 text-sm focus:outline-none focus:border-amber-500"
                />
              </div>
            </div>
          ))}
        </div>

        {/* Footer Actions */}
        <div className="pt-4 border-t border-stone-800 flex items-center justify-between gap-3 shrink-0">
          <button
            onClick={onResetItems}
            className="inline-flex items-center gap-1.5 text-xs text-stone-400 hover:text-white cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>استعادة الأسعار الافتراضية (بيانات طلبات)</span>
          </button>

          <button
            onClick={onClose}
            className="px-5 py-2.5 bg-amber-500 hover:bg-amber-400 text-black text-xs font-bold rounded-xl transition-colors cursor-pointer"
          >
            إغلاق ومعاينة الموقع
          </button>
        </div>

      </div>
    </div>
  );
};
